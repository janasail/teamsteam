<!---
<!DOCTYPE html>
<html style="font-size: 17px;">
  <head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta charset="utf-8">
    <meta name="keywords" content="The key to unlocking your business success!, We&amp;apos;ll help manage your business, We are committed expert partners, Our Tea​m, ​​We create brands for the most innovative and exciting companies in the world, 001-234-5678001-987-7654">
    <meta name="description" content="">
    <title>Home</title>
    <link rel="stylesheet" href="./nicepage-rod.css">
  <link rel="stylesheet" href="./roditelj.css">
  <script src="<?php echo base_url('./js/nicepage.js');?>" ></script>
  <script src="<?php echo base_url('./js/jquery.js');?>" ></script>
  <link rel="stylesheet" type="text/css" href="<?php echo base_url('./css/nicepage-rod.css'); ?> ">
  <link rel="stylesheet" type="text/css" href="<?php echo base_url('./css/roditelj.css'); ?> ">
  <meta name="generator" content="Nicepage 4.12.5, nicepage.com">
    <link id="u-theme-google-font" rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i|Open+Sans:300,300i,400,400i,500,500i,600,600i,700,700i,800,800i">
    
    
    <script type="application/ld+json">{
		"@context": "http://schema.org",
		"@type": "Organization",
		"name": "",
		"logo": "images/KindergartenPic.jpg"
}</script>
    <meta name="theme-color" content="#ad60ee">
    <meta property="og:title" content="Home">
    <meta property="og:type" content="website">
  </head>
  <body data-home-page="Home.html" data-home-page-title="Home" class="u-body u-xl-mode"><header class="u-clearfix u-header u-header" id="sec-8cd7"><div class="u-clearfix u-sheet u-sheet-1">
        <a href="https://nicepage.com" class="u-image u-logo u-image-1" data-image-width="976" data-image-height="838">
        <img src="<?php echo base_url('./images/KindergartenPic.jpg');?>" class="u-logo-image u-logo-image-1">
        </a>
        <nav class="u-menu u-menu-dropdown u-offcanvas u-menu-1">
          <div class="menu-collapse">
            <a class="u-button-style u-nav-link" href="#">
              <svg class="u-svg-link" viewBox="0 0 24 24"><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#svg-3384"></use></svg>
              <svg class="u-svg-content" version="1.1" id="svg-3384" viewBox="0 0 16 16" x="0px" y="0px" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns="http://www.w3.org/2000/svg"><g><rect y="1" width="16" height="2"></rect><rect y="7" width="16" height="2"></rect><rect y="13" width="16" height="2"></rect>
</g></svg>
            </a>
          </div>
          <div class="u-custom-menu u-nav-container">
            <ul class="u-nav u-unstyled"><li class="u-nav-item"><a class="u-button-style u-nav-link" style="padding: 10px 24px;">Info</a>
</li><li class="u-nav-item"><a class="u-button-style u-nav-link" style="padding: 10px 24px;">Moja deca</a>
</li></ul>
          </div>
          <div class="u-custom-menu u-nav-container-collapse">
            <div class="u-black u-container-style u-inner-container-layout u-opacity u-opacity-95 u-sidenav">
              <div class="u-inner-container-layout u-sidenav-overflow">
                <div class="u-menu-close"></div>
                <ul class="u-align-center u-nav u-popupmenu-items u-unstyled u-nav-2"><li class="u-nav-item"><a class="u-button-style u-nav-link">Info</a>
</li><li class="u-nav-item"><a class="u-button-style u-nav-link">Moja deca</a>
</li></ul>
              </div>
            </div>
            <div class="u-black u-menu-overlay u-opacity u-opacity-70"></div>
          </div>
        </nav>
      </div></header> 
      </body>
</html>  --->






      
<!DOCTYPE html>
<html style="font-size: 16px;">
  <head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta charset="utf-8">
    <meta name="keywords" content="">
    <meta name="description" content="">
    <title>Page 1</title>
    <link rel="stylesheet" href="./nicepage.css">
   <link rel="stylesheet" href="./hf.css">
   <script src="<?php echo base_url('./js/nicepage-hf.js');?>" ></script>
   <script src="<?php echo base_url('./js/jquery-hf.js');?>" ></script>
   <link rel="stylesheet" type="text/css" href="<?php echo base_url('./css/nicepage.css'); ?> ">
   <link rel="stylesheet" type="text/css" href="<?php echo base_url('./css/hf.css'); ?> ">
    <meta name="generator" content="Nicepage 4.12.5, nicepage.com">
    <link id="u-theme-google-font" rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i|Open+Sans:300,300i,400,400i,500,500i,600,600i,700,700i,800,800i">
    
    <script type="application/ld+json">{
		"@context": "http://schema.org",
		"@type": "Organization",
		"name": "",
		"logo": "images/KindergartenPic.jpg"
}</script>


<script language="JavaScript">

        function myFunction() {
  var x = document.getElementById("informacije");
  var y = document.getElementById("deca");

    x.style.display = "block";
    y.style.display = "none";

}

function myFunction2() {
  var x = document.getElementById("informacije");
  var y = document.getElementById("deca");
    x.style.display = "none";
    y.style.display = "block";
}
function myFunction3() {
  var x = document.getElementById("informacije");
  var y = document.getElementById("deca");
    x.style.display = "block";
    y.style.display = "none";

}
window.onload = myFunction3;
      </script>
    <meta name="theme-color" content="#b1363e">
    <meta property="og:title" content="Page 1">
    <meta property="og:type" content="website">
  </head>
  <body class="u-body u-xl-mode"><header class="u-clearfix u-header u-header" id="sec-c9a0"><div class="u-clearfix u-sheet u-sheet-1">
        <a href="#" class="u-image u-logo u-image-1" data-image-width="976" data-image-height="838">
          <img src="<?php echo base_url('./images/KindergartenPic.jpg');?>"  class="u-logo-image u-logo-image-1">
        </a>
        <nav class="u-menu u-menu-dropdown u-offcanvas u-menu-1">
          <div class="menu-collapse" style="font-size: 1rem; letter-spacing: 0px;">
            <a class="u-button-style u-custom-left-right-menu-spacing u-custom-padding-bottom u-custom-top-bottom-menu-spacing u-nav-link u-text-active-palette-1-base u-text-hover-palette-2-base" href="#">
              <svg class="u-svg-link" viewBox="0 0 24 24"><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#menu-hamburger"></use></svg>
              <svg class="u-svg-content" version="1.1" id="menu-hamburger" viewBox="0 0 16 16" x="0px" y="0px" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns="http://www.w3.org/2000/svg"><g><rect y="1" width="16" height="2"></rect><rect y="7" width="16" height="2"></rect><rect y="13" width="16" height="2"></rect>
</g></svg>
            </a>
          </div>
          <div class="u-custom-menu u-nav-container">
          <ul class="u-nav u-spacing-25 u-unstyled u-nav-1"><li class="u-nav-item"><a class="u-button-style u-nav-link" onclick= myFunction() data-page-id="89465412" style="padding: 8px 0px;">Info</a>
</li><li class="u-nav-item"><a class="u-button-style u-nav-link" onclick= myFunction2();function1() data-page-id="89465412" style="padding: 8px 0px;">Moja deca</a>
</li></ul>
          </div>
          <div class="u-custom-menu u-nav-container-collapse">
            <div class="u-black u-container-style u-inner-container-layout u-opacity u-opacity-95 u-sidenav">
              <div class="u-inner-container-layout u-sidenav-overflow">
                <div class="u-menu-close"></div>
                <ul class="u-align-center u-nav u-popupmenu-items u-unstyled u-nav-2"><li class="u-nav-item"><a class="u-button-style u-nav-link" onclick= myFunction() data-page-id="89465412">Info</a>
</li><li class="u-nav-item"><a class="u-button-style u-nav-link" onclick= myFunction2() data-page-id="89465412">Moja deca</a>
</li> </ul>
              </div>
            </div>
            <div class="u-black u-menu-overlay u-opacity u-opacity-70"></div>
          </div>
        </nav>
      </div></header> 
  </body>
</html>