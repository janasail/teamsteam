<html>
    <head>
        <title>Moj vrtić</title>
    </head>
    <body>
        <?= anchor("Vaspitac/index", "Vesti") ?> 
        <div style="float: right">
            <?= anchor("Vaspitac/login", "Uloguj se") ?>
        </div>
        <br>
        <hr>