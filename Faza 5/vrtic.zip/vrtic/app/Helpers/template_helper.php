<?php
function add_assets()
{
    return "Test helper";
}